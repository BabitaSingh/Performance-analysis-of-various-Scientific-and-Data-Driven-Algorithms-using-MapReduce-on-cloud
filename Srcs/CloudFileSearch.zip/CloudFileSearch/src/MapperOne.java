import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;


public class MapperOne extends Mapper<LongWritable,Text,Text,LongWritable>
{
	  String filename;
	  int lineNumber;
	
	@Override
	protected void map(LongWritable key, Text value, Context context)
	throws IOException, InterruptedException 
	{
		if(value.toString().contains("America"))
		{
			 FileSplit fileSplit = (FileSplit)context.getInputSplit();
			  String filename = fileSplit.getPath().getName();
			  System.out.println("File name "+filename);
			context.write(new Text(filename), new LongWritable(Integer.valueOf(lineNumber)));
		}
		else
		{
			lineNumber++;
		}
	}



}
