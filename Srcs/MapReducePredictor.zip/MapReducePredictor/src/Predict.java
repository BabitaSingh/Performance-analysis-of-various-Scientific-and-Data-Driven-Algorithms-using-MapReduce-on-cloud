import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Predict {

	void PredictSemantics() throws IOException
	{
		BufferedWriter bw = null;
		File file = new File("C://Users//user//Desktop//OP.txt");
		Scanner fileScanner = new Scanner(new File("C://Users//user//Desktop//Test.txt"));
		
		if (!file.exists()) 
		{
			file.createNewFile();
		}

		FileWriter fw = new FileWriter(file);
		bw = new BufferedWriter(fw);
			  
			  
		while (fileScanner.hasNext())
		{
			String inputString = fileScanner.nextLine();
			String originalString = new String(inputString);
			int prediction = 0;
			
			inputString = inputString.replaceAll("[^a-zA-Z0-9\\s]", "");
			inputString = inputString.replaceAll("\\w*\\d\\w*", "");

			String[] tokens = inputString.split("\\s+");
			
			for(int i = 0; i < tokens.length; i++)
			{
				tokens[i] = tokens[i].toLowerCase();
				if(Storage.map.containsKey(tokens[i]))
				{
					prediction = prediction + Storage.map.get(tokens[i]);
				}
			}
			if(prediction > 0)
			{
				System.out.println("Positive");
				bw.write("Positive : " + originalString);
				bw.newLine();
			}
			else
			{
				System.out.println("Negative");
				bw.write("Negative : " + originalString);
				bw.newLine();
			}
		}
		 bw.close();
	}
}
