import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MapperOne extends Mapper<LongWritable,Text,Text,LongWritable>
{
	@Override
    protected void map(LongWritable key, Text value, Context context)
    		throws IOException, InterruptedException 
   {
		
		File theFile = new File("C://Users//user//Desktop//StopWords.txt");
		
		String inputString = value.toString();
		Character c = inputString.charAt(0);
		
		
		inputString = inputString.replaceAll("[^a-zA-Z0-9\\s]", "");
		inputString = inputString.replaceAll("\\w*\\d\\w*", "");
		
		String[] tokens = inputString.split("\\s+");
		
		for(int i = 1; i < tokens.length; i++)
		{
			tokens[i] = tokens[i].toLowerCase();
			if(!CheckWord(tokens[i], theFile))
			{	
				System.out.println(tokens[0] + " " + tokens[i]);
				context.write(new Text(tokens[i]), new LongWritable(Character.getNumericValue(c)));
			}
		}
    }
	
	public static boolean CheckWord(String theWord, File theFile) throws FileNotFoundException 
	{
	    return (new Scanner(theFile).useDelimiter("\\Z").next()).contains(theWord);
	}
	
}
