import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;


public class ReducerOne extends Reducer<Text,LongWritable,Text,LongWritable> 
{
	@Override
	protected void reduce(Text key, Iterable<LongWritable> values, Context context)
			throws IOException, InterruptedException 
	{

		int count = 0;
		for (LongWritable val : values) 
		{
			if (val.get() == 1)
			{
				count++;
			}
			else
			{
				count--;
			}
		}
		Storage.map.put(key.toString(), Integer.valueOf(count));	
		context.write(key, new LongWritable(Integer.valueOf(count)));
	}
}
