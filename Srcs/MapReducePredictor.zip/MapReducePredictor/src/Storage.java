import java.util.HashMap;


public class Storage {

	static HashMap<String, Integer> map = new HashMap<String, Integer>();
	
	
}
